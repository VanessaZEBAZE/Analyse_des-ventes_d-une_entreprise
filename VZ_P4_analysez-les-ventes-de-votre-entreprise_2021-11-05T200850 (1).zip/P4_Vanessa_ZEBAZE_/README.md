FICHIER README 

Sommaire

Pour ce projet, les données ont été manipulées en Python. 

Le travail s'est axé sur la pratique des bases de la statistique descriptive (moyenne, médiane, variance, représentations graphiques, tests de corrélation, analyse bivariée).

- Les données

Les données utilisés pour la réalisation de ce projet sonr ds fichiers cvs fournies par dans le projet et qui proviennent de la BD  de l’entreprise . Voici les explications :

les ventes (appelées “Transactions”);
la liste des clients;
la liste des produits.

- Ouvrir les différents livrables.

Si vous n'avez jamais installé Python, alors autant installer directement la distribution Anaconda. Anaconda est donc une distribution Python, faite pour la Data Science.

C'est par ici https://www.anaconda.com/products/individual

Si vous souhaitez lancer le projet ( les différents script) et les visualiser avec les graphiques ou si vous souhaitez visualiser chacun des livrales séparément, il sera nécessaire d'installer Jupyter Notebook sur votre machine. La documentation Jupyter est accessible via : https://jupyter.readthedocs.io/en/latest/install.html

ou taper dans votre terminal les commandes suivantes :

python -m pip install --upgrade pip    
python -m pip install jupyter

Pour tester l'installation, vous pouvez taper dans votre console la commande suivante :

jupyter notebook

Ensuite , après l'installation du logiciel , veuillez à installer les librairies appropriées ci-dessous

Installation des librairies Python uniquement
Pour installer python ainsi que les librairies de Data Science, il est fortement recommandé d'installer la distribution Anaconda.

- pip install pandas
- pip install matplotlib
- pip install numpy
- pip install scipy
