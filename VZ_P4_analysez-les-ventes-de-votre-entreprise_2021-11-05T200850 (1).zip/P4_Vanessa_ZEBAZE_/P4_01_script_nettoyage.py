#!/usr/bin/env python
# coding: utf-8

# CONTEXTE DE L'ETUDE: Je suis Data Analyst d'une grande chaîne de librairie, fraîchement embauchée depuis une semaine ! "Rester livres" s'est d'abord développée dans une grande ville de France, avec plusieurs magasins, jusqu'à décider d'ouvrir une boutique en ligne. Son approche de la vente de livres en ligne, basée sur des algorithmes de recommandation, lui a valu un franc succès ! Voyons plus en détail l'approche Business de l'exploitation…

# In[1]:


#Import des librairies Python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as st
import math as mth


# In[2]:


#Définition des paramètres graphiques
plt.style.use('ggplot')
plt.rcParams['figure.figsize'] = [14, 7]
plt.rcParams['font.size'] = 16


# In[3]:


#Import des fichiers csv extraits directement de la base de données de l’entreprise
df_transactions = pd.read_csv('transactions.csv') #les ventes (appelées “Transactions”)
df_products = pd.read_csv('products.csv') #la liste des produits
df_customers = pd.read_csv('customers.csv') #la liste des clients


# In[4]:


#Visualisation rapide des 3 dataframes
print(df_products.info())
print("----")
print(df_customers.info())
print("----")
print(df_transactions.info())


# # Mission 1 : Nettoyage des données de base

# ## Traitement des valeurs manquantes

# In[5]:


# La méthode .isnull() (ou .isna()) sur le df produits, renvoie des booléens par colonne
df_products.isnull().any()


# Aucune valeur manquante dans le df_products.

# In[7]:


# La méthode .isnull() sur le df clients, renvoie des booléens par colonne
df_customers.isnull().any()


# Aucune valeur manquante dans df_customers.

# In[8]:


# La méthode .isnull() sur le df transactions, renvoie des booléens par colonne
df_transactions.isnull().any()


# Aucune valeur manquante dans df_transactions.

# ## Vérification des valeurs abberantes et atypiques et leur traitement 

# Par valeurs aberrantes,il s'agit d'identifier des valeurs vraisemblablement fausses, et pour les valeurs atypiques elles restent possibles, pas forcément fausses.

# ### Analyse et correction éventuelle du dataframe df_products

# In[10]:


# Effectuons un tri sur les 5 premières lignes du df_product à partir de la (méthode .sort_values())
df_products.sort_values('id_prod', ascending = False).head()


# In[11]:


#  Effectuons un tri sur les 5 dernières lignes du df_products
df_products.sort_values('id_prod', ascending = False).tail()


# On constate clairemet au travers de ces tri que la ligne index 731,son id_prod T_0 et son price ne sont pas acceptables (présence des valeurs test et d'une valeur négative).

# In[12]:


# Effectuons une seconde vérification dans le df products pour s'arrurer qu'il n'yait pas d'autres valeurs negatives ou de test 
# Vérification par restriction des valeurs négatives (ou nulles) dans df_products
df_products[df_products.price <= 0]


# La liste des produits vendus recense une seule valeur négative (- 1€) très certainement liée à une transaction de test.

# In[14]:


#Suppression de la ligne index 731 car la valeur n'a aucune signification logique
df_products = df_products[df_products.id_prod != 'T_0']


# In[15]:


# Effectuons une autre analyse en vue de la vérification de la cohérence des prix produits
print(df_products.price.min())
print(df_products.price.max())


# Aucune anomalie sur les prix min. et max., les prix produits en queue de distribution sont plausibles.

# ### Analyse et correction éventuelle du dataframe df_customers

# In[17]:


# Effectuons un tri sur les 5 premières lignes du dataframe df_customers (méthode .sort_values())
df_customers.sort_values('client_id', ascending = False).head()


# In[18]:


# Effectuons un tri sur les 5 dernières lignes du dataframe df_customers
df_customers.sort_values('client_id', ascending = False).tail()


# client_id, ct_1 et ct_0 n'ont pas la même forme d'écriture que le reste, le "ct" ressemble à un identifiant de test.

# In[19]:


#Suppression des deux lignes client_id ct_1 et ct_0
df_customers = df_customers[(df_customers.client_id != 'ct_0') & (df_customers.client_id != 'ct_1')]


# In[20]:


#Vérification de la cohérence des âges clients
print(df_customers.sort_values(by='birth', ascending=False).head())
print(df_customers.sort_values(by='birth', ascending=True).head())


# Les plus jeunes clients ont 18 ans, les plus âgés 93 ans. Aucune anomalie.

# ### Analyse et correction éventuelle du dataframe df_transactions 

# In[21]:


# Effectuons un tri rapide sur les 5 premières lignes du dataframe df_transactions (méthode .sort_values())
df_transactions.sort_values('client_id', ascending = False).head()


# In[22]:


# Effectuons un tri sur les 5 dernières lignes du dataframe df_transactions
df_transactions.sort_values('client_id', ascending = False).tail()


# Identification de nouvelles valeurs "test" liés directement aux client_id ct_1 identifiés précédement.

# In[23]:


#Suppression des valeurs test
df_transactions = df_transactions[df_transactions.id_prod != 'T_0']


# In[24]:


#Conversion des valeurs de la colonne 'date' dans le bon format date (méthode .to_datetime())
df_transactions['date'] = pd.to_datetime(df_transactions.date, format='%Y-%m-%d %H:%M:%S', errors = 'coerce')

#Vérification du type de données
df_transactions.dtypes


# In[25]:


#L'argument "errors = 'coerce'" de la méthode renvoie (NaT) si la conversion n'est pas possible
#Vérification des éventuelles valeurs manquantes
df_transactions.date.isnull().sum()


# ## Traitement des éventuels doublons

# In[26]:


#Méthode .duplicated() pour identifier la présence de doublons
print(df_products.duplicated().sum())
print(df_customers.duplicated().sum())
print(df_transactions.duplicated().sum())


# Aucun doublon détecté dans nos 3 dataframes.

# En conclusion, à ce stade de l'analyse, seules des valeurs dites "test" ont été supprimées pour ne pas fausser l'étude. Il n'y a pas vraiment de valeurs atypiques, les prix en queue de distribution restent cohérents, ainsi que les clients les plus âgés.

# In[ ]:




