#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Import des librairies Python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as st
import math as mth


# In[2]:


#Paramètres graphiques
plt.style.use('ggplot')
plt.rcParams['figure.figsize'] = [14, 7]
plt.rcParams['font.size'] = 16


# In[3]:


#Import des fichiers csv extraits directement de la base de données de l’entreprise
df_transactions = pd.read_csv('transactions.csv') #les ventes (appelées “Transactions”)
df_products = pd.read_csv('products.csv') #la liste des produits
df_customers = pd.read_csv('customers.csv') #la liste des clients


# In[4]:


#Visualisation rapide de nos 3 dataframes
print(df_products.info())
print("----")
print(df_customers.info())
print("----")
print(df_transactions.info())


# # Mission 2 : Analyse des données

# ### Vue sur les variables des 3 dataframes (définition de la typologie)

# Variables qualitatives :

# - Les id (client_id, id_prod, session_id)
# 
# - Les dates de transactions (de 2021-03-01 à 2022-02-28)
# 
# - Le sexe des clients (f ou m)
# 
# - Les catégories produits (0, 1 ou 2)

# Variable quantitative :

# Les prix des produits

# Afin de mieux comprendre les ventes, l'analyse portera principalement sur les dimensions suivantes :

# - L'évolution des ventes (Chiffre d'Affaires)
# 
# - Les prix produits pratiqués
# 
# - La répartition sectorielle (par Catégorie)
# 
# - La répartition démographique (par âge et sexe client)
# 
# - Le comportement client (fidélisation)
# 
# - Corrélation, lien(s) possible(s) entre les variables

# ## Préparation des données  de transactions et produits

# In[6]:


#Jointure pour agréger les valeurs 'transactions' avec celles 'products' (méthode .merge())
df_transactions_products = pd.merge(df_transactions, df_products, on='id_prod', how='left')
df_transactions_products.head()


# In[7]:


#Vérification d'éventuelles valeurs manquantes (méthode .isnull())
df_transactions_products.isnull().sum()


# In[8]:


#Aucun id produit manquant, il est intéressant de détecter le ou les produits concernés par les valeurs manquantes
#Création d'un dataframe ciblant uniquement ces NaN
df_missing_values = df_transactions_products[df_transactions_products.categ.isnull() == True]


# In[9]:


#Recherche du ou des produits concernés
df_missing_values.id_prod.unique()


# In[10]:


#On note 103 lignes non exploitables dans l'état pour le produit id 0_2245
#Il est préférable de les conserver en remplacant les prix NaN par le prix moyen
df_transactions_products['price'] = df_transactions_products.price.fillna(df_transactions_products.price.mean())


# In[11]:


#Le produit id 0_2245 doit-être classifié en catégorie 0, il commence par "0_"
#Méthode .fillna() pour remplacer les NaN de la variable catégorie par 0
df_transactions_products['categ'] = df_transactions_products.categ.fillna(0)


# In[12]:


#22 individus restants sans date, sans session_id et sans client_id
#Il n'y pas de solution immédiate pour pouvoir obtenir des indications sur la date, la session…
#Il est préférable de les supprimer pour les exclure de l'analyse
df_transactions_products[df_transactions_products.date.isnull() == True]


# In[13]:


#Suppression des 22 dernières lignes avec valeurs manquantes (celles affichées ci-dessus)
df_transactions_products = df_transactions_products.dropna()


# In[14]:


#Nouvelle vérification des valeurs manquantes, normalement les catégories sont désormais sans NaN
df_transactions_products.isnull().sum()


# ## Analyse de l'évolution du chiffre d'affaires (CA)

# In[16]:


df_transactions_products


# In[17]:


df_transactions_products['date']


# In[18]:


#Conversion des valeurs de la colonne 'date' dans le bon format date (méthode .to_datetime())
df_transactions_products['date'] = pd.to_datetime(df_transactions_products.date, format='%Y-%m-%d %H:%M:%S', errors = 'coerce')

#Vérification du type de données
df_transactions_products.dtypes


# In[19]:


#Agrégation des données transactionnelles par fréquence mensuelle (méthode .groupby())
df_transactions_months = df_transactions_products.groupby(pd.Grouper(key='date', freq='M')).sum().reset_index()

df_transactions_months['ventes_keuros'] = df_transactions_months.price / 1000
df_transactions_months = df_transactions_months[['date', 'ventes_keuros']]
df_transactions_months


# In[20]:


#Visualisation de l'évolution des ventes sur les 12 derniers mois
df_transactions_months.plot(x='date', y='ventes_keuros')

plt.title('Evolution du chiffre d affaire')
plt.xlabel('Date')
plt.ylabel('Ventes K€')

plt.savefig("evolution_ventes.png")
plt.show()


# Au travers de ce graphique on note une baisse d'activité significative au cours du mois d'octobre. Quelle peut en être la raison? 

# In[21]:


#Restriction selon les dates du mois d'octobre
transaction_october = len(df_transactions_products[(df_transactions_products.date > '2021-09-30') &                                                    (df_transactions_products.date < '2021-11-01')])
transaction_october


# In[22]:


#Restriction selon les dates du mois de septembre
transaction_september = len(df_transactions_products[(df_transactions_products.date > '2021-08-31') &                                                      (df_transactions_products.date < '2021-10-01')])
transaction_september


# Il semble manquer des valeurs sur le mois d'octobre, la visualisation le montre, et le nombre de lignes identifiées sur la période semble le confirmer également. Une vérification supplémentaire est nécessaire.

# In[23]:


#Restriction par catégorie pour identifier les valeurs manquantes sur le mois d'octobre
df_transactions_products[(df_transactions_products.categ == 1) & (df_transactions_products.date > '2021-10-02') &                                                    (df_transactions_products.date < '2021-10-28')]


# In[24]:


#Restriction par catégorie pour identifier les valeurs manquantes sur le mois d'octobre
df_transactions_products[(df_transactions_products.categ == 0) & (df_transactions_products.date > '2021-10-02') &                                                    (df_transactions_products.date < '2021-10-28')]


# In[25]:


#Restriction par catégorie pour identifier les valeurs manquantes sur le mois d'octobre
df_transactions_products[(df_transactions_products.categ == 2) & (df_transactions_products.date > '2021-10-02') &                                                    (df_transactions_products.date < '2021-10-28')]


# Aucune transaction sur les produits de catégorie 1 durant le mois d'octobre.

# Pour la suite de l'étude le mois d'octobre ne sera pas pris en compte, l'analyse se fera sur 11 mois au lieu de 12.

# In[27]:


#Création (par restriction des dates)du dataframe 'df_transactionsv1' excluant les transactions du mois d'octobre
df_transactionsv1 =  df_transactions[(df_transactions.date <= '2021-09-30') | (df_transactions.date >= '2021-11-01')]


# In[28]:


#Nouvelle jointure pour agréger les valeurs 'transactionsv1' avec celles 'products' (méthode .merge())
df_transactionsv1_products = pd.merge(df_transactionsv1, df_products, on='id_prod')
df_transactionsv1_products.head()


# ### Serie temporelle: analyse du nombre de vente en fonction des jours de la semaine

# L'objectif est de déterminer le jour de la semaine pour lequel on a réalisé le chiffre d'affaire le plus important

# In[29]:


df_transactionsv1_products.head()


# In[30]:


df_transactionsv1_products['date']


# In[31]:


# la date n'est pas au bon format. Nous devons la concertir au format approprié


# In[32]:


#Conversion des valeurs de la colonne 'date' dans le bon format date (méthode .to_datetime())
df_transactionsv1_products['date'] = pd.to_datetime(df_transactionsv1_products.date, format='%Y-%m-%d %H:%M:%S', errors = 'coerce')

#Vérification du type de données
df_transactionsv1_products.dtypes


# In[33]:


df_transactionsv1_products['date']


# In[34]:


# Une série temporelle est une série dont l'index est le temps. Nous allons donc transformer nos index en date


# In[35]:


df_transactionsv1_products=df_transactionsv1_products.set_index('date')


# In[36]:


df_transactionsv1_products.head()


# In[37]:


df_transactionsv1_products.index


# In[39]:


#Affichons 5 éléments de l'index


# In[38]:


df_transactionsv1_products.index[:5]


# In[41]:


#Affichons les jours


# In[40]:


df_transactionsv1_products.index[:5].day


# In[42]:


#Affichons également pour visualisation le nom des diferents jours


# In[43]:


df_transactionsv1_products.index[:5].day_name()


# In[47]:


#Agrégation des données transactionnelles par fréquence journalière (méthode .groupby())
df_transactions_days = df_transactionsv1_products.groupby(pd.Grouper(freq='D')).sum().reset_index()

df_transactions_days['ventes_keuros'] = df_transactions_days.price / 1000
df_transactions_days = df_transactions_days[['date', 'ventes_keuros']]
df_transactions_days


# In[48]:


df_transactions_days=df_transactions_days.set_index('date')


# In[49]:


df_transactions_days.head()


# In[50]:


#création de la colonnes ( feature) relative au jour de la semaine


# In[51]:


df_transactions_days['day_name']=df_transactions_days.index.day_name()


# In[52]:


df_transactions_days.head()


# Quel est le jour avec le plus de vente?

# In[53]:


df_transactions_days.groupby('day_name').sum()['ventes_keuros'].sort_values()


# In[54]:


groupday=df_transactions_days.groupby('day_name').sum()['ventes_keuros'].reset_index()
groupday


# In[58]:


# visualisation
order=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
sns.barplot(x=groupday['day_name'],y=groupday['ventes_keuros'],order=order)
plt.title('Ventes par jour')
plt.savefig("Ventes.png")
plt.show()


# In[124]:


df_transactions_days.groupby('day_name').mean()['ventes_keuros'].sort_values()


# In[125]:


groupday=df_transactions_days.groupby('day_name').mean()['ventes_keuros'].reset_index()
groupday


# In[127]:


# visualisation
order=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
sns.barplot(x=groupday['day_name'],y=groupday['ventes_keuros'],order=order)
plt.title('Moyenne des ventes par jour')
plt.savefig("Moyenne ventes.png")
plt.show()


# In[128]:


# On constate qu'il n'ya pas spécifiquement de jour pendant lesquelles les clients achetent plus. Les ventes sont lissées dans la semaine


# ## Analyse des prix pratiqués : variable 'price' (df_transactionsv1_products)¶

# ### Mesures de tendance centrale et dispersion des prix produits (toutes catégories confondues)¶

# In[59]:


#Calcul de la Moyenne des prix produits vendus 
round(df_transactionsv1_products['price'].mean(), 2)


# In[60]:


#Calcul de la Mediane des prix produits vendus
df_transactionsv1_products['price'].median()


# In[61]:


#Calcul du Mode des prix produits vendus
df_transactionsv1_products['price'].mode()


# In[62]:


#Calcul de la Variance des prix produits vendus
round(df_transactionsv1_products['price'].var(ddof=0), 2)


# In[63]:


#Calcul de l'écart type des prix produits vendus 
round(df_transactionsv1_products['price'].std(ddof=0), 2)


# In[64]:


#Visualisation (Histogramme)de la distribution des prix de produits
df_transactionsv1_products['price'].hist(color='#0504aa', alpha=0.5, density=True, bins=20)

plt.title('Distribution de la variable "price"')
plt.xlabel('Prix produits(€)')
plt.ylabel('Fréquence d\'apparition')

plt.savefig("distribution_price.png")
plt.show()


# In[65]:


#Courbe de Lorenz sur la variables des prix
price = df_transactionsv1_products['price'].values
#Sélection du sous-échantillon de travail que l'on appelle price

#On place les observations dans une variable
lorenz_price = np.cumsum(np.sort(price)) / price.sum()
#Tri des individus dans l'ordre croissant des valeurs de la variable, 
#Calcul de la somme cumulée et normalisation en divisant par la somme des observations

plt.plot(np.linspace(0,1,len(lorenz_price)), lorenz_price, drawstyle='steps-post', color='rosybrown', label='Lorenz')
plt.fill_between(np.linspace(0,1,len(lorenz_price)) ,lorenz_price , color='#539ecd')
plt.plot([0, 1], [0, 1], 'r-', lw=2, label='Distribution égalitaire')
plt.vlines(x=.76, ymin=0, ymax=.5, color='blue', linestyle='--', linewidth=1, label='Medial')
plt.hlines(xmin=.76, xmax=0, y=.5, color='blue', linestyle='--', linewidth=1)

plt.title('Courbe de Lorenz des prix de vente')
plt.xlabel("Distribution des ventes (%)")
plt.ylabel("Cumul des prix de ventes (%)")
plt.legend(loc="best")

plt.savefig("lorenz_price.png")
plt.show()


# On constate que 76% des ventes représentent 50% du montant total des prix de vente. Ce n'est pas une égalité totale, mais acceptable dans notre contexte business.

# In[66]:


#Aire sous la courbe de Lorenz. La dernière valeur ne participe pas à l'aire, d'où "[:-1]"
aire_ss_courbe_price = lorenz_price[:-1].sum()/len(lorenz_price) 

#Aire entre la 1e bissectrice et la courbe de Lorenz
S = 0.5 - aire_ss_courbe_price 
gini_price = round(2*S, 2)

print("L'indice de Gini est égal à {}".format(gini_price))


# Confirmation avec l'indice de Gini plus proche de 0 que de 1, les prix pratiqués ont tendance à être équitables.

# ### Analyse sectorielle de l'activité : variable 'categ' (df_transactionsv1_products)

# In[67]:


#Représentation des effectifs par catégories de vente(méthode .value_counts())
effectif = df_transactionsv1_products['categ'].value_counts()
modalite = effectif.index #l'index de 'effectifs' contient les modalités

tab = pd.DataFrame(modalite, columns = ['categ']) #création du tableau à partir des modalités
tab["n"] = effectif.values
tab["f"] = tab["n"] / len(df_transactionsv1_products) #len(df_transactionsv1_products) renvoie la taille de l'échantillon
tab


# In[68]:


#Pie Chart pour représenter la part de chacune des catégories de vente
labels = 'Cat 0', 'Cat 1', 'Cat 2'
sizes = tab['f']
explode = (0.06, 0, 0)

fig1, ax1 = plt.subplots(figsize=(12,6))
ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%', shadow=False, startangle=90)

ax1.axis('equal') 
plt.title('Répartition des catégories')
plt.savefig("repartition_categories.png")
plt.show()


# In[71]:


#Comparaison de distribution des prix produits par catégorie avec Seaborn
sns.boxplot(x = 'categ', y = 'price', data = df_transactionsv1_products, palette="Set2")
plt.title('Dispersion des prix de vente par catégorie')
plt.savefig("dispersion_categories.png")
plt.show()


# Les 3 catégories n'ont pas les mêmes types (ou gamme)de produits. La catégorie 2 par exemple a un prix moyen proche des 60€ avec des outliers en queue de distribution jusqu'à 300€.

# ## Analyse des produits disponibles par catégorie

# In[72]:


#Comptage des produits présents en catégorie 0
len(df_products[df_products.categ == 0].groupby('id_prod'))


# In[73]:


#Comptage des produits présents en catégorie 1
len(df_products[df_products.categ == 1].groupby('id_prod'))


# In[74]:


#Comptage des produits présents en catégorie 2
len(df_products[df_products.categ == 2].groupby('id_prod'))


# Une offre produit qui reste cohérente devant les transactions enregistrées, avec visiblement peu de choix en catégorie 2.

# ## Analyse démographique de l'activité

# ### Variable 'birth' (df_transactions_customers)

# In[75]:


#Préparation des données… Jointure des données transactionnelles et clients (méthode .merge())
df_transactionsv1_customers = pd.merge(df_transactionsv1, df_customers, on='client_id')
df_transactionsv1_customers.head()


# In[76]:


#Ajout d'une colonne'age' pour faciliter l'analyse
df_transactionsv1_customers['age'] = 2022 - df_transactionsv1_customers.birth


# In[77]:


#Visualisation (Histogramme)de la distribution de l'âge clients
df_transactionsv1_customers['age'].hist(density=True, alpha=0.5, bins=20)

plt.xlabel('Âges')
plt.title('Distribution des âges clients')
plt.savefig("distribution_ages_clients.png")
plt.show()


# La majeure partie des clients se concentrent entre 30 et 55 ans.

# #### Mesure de concentration des âges clients

# In[78]:


#Courbe de Lorenz sur la variable des âges 
ages = df_transactionsv1_customers['age'].values
# Sélection du sous-échantillon de travail que l'on appelle ages

#On place les observations dans une variable
lorenz_ages = np.cumsum(np.sort(ages)) / ages.sum()
#Tri des individus dans l'ordre croissant des valeurs de la variable, 
#Calcul de la somme cumulée et normalisation en divisant par la somme des observations

plt.plot(np.linspace(0,1,len(lorenz_ages)), lorenz_ages, drawstyle='steps-post', color='rosybrown', label='Lorenz')
plt.fill_between(np.linspace(0,1,len(lorenz_ages)) ,lorenz_ages , color='#539ecd')
plt.plot([0, 1], [0, 1], 'r-', lw=2, label='Distribution égalitaire')
plt.vlines(x=.61, ymin=0, ymax=.5, color='blue', linestyle='--', linewidth=1, label='Medial')
plt.hlines(xmin=.61, xmax=0, y=.5, color='blue', linestyle='--', linewidth=1)

plt.title('Courbe de Lorenz des âges clients')
plt.xlabel("Distribution des âges (%)")
plt.ylabel("Cumul des âges clients (%)")

plt.legend(loc="best")
plt.savefig("lorenz_age.png")
plt.show()


# On constate qu'environ 61% des âges clients représentent 50% du montant total des âges. C'est une égalité quasi parfaite, et nous pouvons le confirmer avec l'indice de Gini.

# In[79]:


#Aire sous la courbe de Lorenz. La dernière valeur ne participe pas à l'aire, d'où "[:-1]"
aire_ss_courbe_age = lorenz_ages[:-1].sum()/len(lorenz_ages) 

#Aire entre la 1e bissectrice et la courbe de Lorenz
S = 0.5 - aire_ss_courbe_age
gini_age = round(2*S, 2)

print("L'indice de Gini est égal à {}".format(gini_age))


# Confirmation avec l'indice de Gini très proche de 0, les âges clients sont bien répartis, quasiment égalitaire dans notre contexte.

# ### Variable 'sex' (df_transactionsv1_customers)

# In[80]:


#Méthode .value_counts() pour avoir une idée rapide de la répartition homme/femme chez les clients
df_transactionsv1_customers['sex'].value_counts()


# In[81]:


#Préparation des données par jointure pour agréger les valeurs 'customers' avec celles 'transactionsv1_products'
df = pd.merge(df_customers, df_transactionsv1_products)
df.head()


# In[82]:


#Méthode .pivot_table() pour affiner davantage la répartition des hommes et des femmes selon la catégorie d'achat
#Utilisation de df (étape précedente)obtenu par jointure avec df_customers et df_transactionsv1_products
fm = df.pivot_table(index='sex', columns='categ', values='price', aggfunc=sum).reset_index()


# In[83]:


fm.plot(kind='bar', x='sex')

plt.title('Répartition Hommes/Femmes selon les catégories')
plt.xlabel('Sexe clients')
plt.ylabel('Montant acheté')

plt.savefig("sex_categ.png")
plt.show()


# L'échantillon étudié ressort avec une égalité quasi parfaite entre les hommes et les femmes.

# ## Analyse comportementale des clients

# ### Analyse des transactions par client

# In[84]:


#Préparation des données par jointure pour agréger les valeurs 'customers' avec celles 'transactionsv1_products'
df = pd.merge(df_customers, df_transactionsv1_products)
df.head()


# In[85]:


#Agrégation des modalités de la variable 'client_id' (méthode .groupby())
#L'objectif est de comprendre l'action de ré-achat (ou non)des clients
fid_client = df.groupby('client_id').count().reset_index()
fid_client['nb_transac'] = fid_client.session_id
fid_client = fid_client[['client_id', 'nb_transac']]
fid_client.head()


# In[86]:


#Estimation des clients ayant passés plus d'une commande dans l'année
fid_client[fid_client['nb_transac'] > 1].shape[0]


# In[87]:


#Estimation des clients ayant passés une seule commande dans l'année
fid_client[fid_client['nb_transac'] == 1].shape[0]


# In[88]:


#Estimation des clients ayant passés 2 commandes dans l'année
fid_client[fid_client['nb_transac'] == 2].shape[0]


# Excellente fidélisation des clients qui n'hésitent pas à revenir pour un nouvel achat.

# ## Analyse des centres d'intérêt client : "Catégorie d'affinité

# In[89]:


#Analyse des quantités de produits vendus selon les catéories
categ_prod = df.groupby('categ').price.count().reset_index()
categ_prod


# In[90]:


#Analyse du chiffre d'affaires selon les catégories
categ_sales = df.groupby('categ').price.sum().reset_index()
categ_sales


# La catégorie 2 ressort moins populaire que les deux autres, moins de quantités vendues, moins de chiffre d'affaires, mais un panier moyen qui reste beaucoup plus élevé.

# L'analyse va se poursuivre sur l'étude des liens éventuels entre les précédentes variables. L'enjeu est de comprendre les corrélations possibles ou non, de manière à pouvoir tirer des conclusions qui aidera l'entreprise à prendre des décisions stratégiques.

# # Mission 3 : les corrélations

# Les corrélations indiquent si deux variables sont linéairement équivalentes.

# Voici quelques questions supplémentaires pour nous aider à mieux comprendre les ventes enregistrées.

# - Y a-t-il une corrélation entre le sexe des clients et les catégories de produits achetés ?
# 
# - Y a-t-il une corrélation entre l'âge des clients et le montant total des achats ?
# 
# - Y a-t-il une corrélation entre l'âge des clients et la fréquence d’achat (nombre d'achats par mois) ?
# 
# - Y a-t-il une corrélation entre l'âge des clients et la taille du panier moyen (en nombre d’articles) ?
# 
# - Y a-t-il une corrélation entre l'âge des clients et les catégories de produits achetés ?

# In[91]:


## Préparation des données : Jointure des 3 dataframes


# Pour mieux comprendre cette analyse il est important d'ajouter une colonne 'age'.

# In[92]:


#Utilisation du dataframe df résultant de la jointure de df_customers, df_transactionsv1_products
df['age'] = 2022 - df.birth


# In[93]:


#Visualisation des catégories de df
df.dtypes


# In[94]:


#Visualisation de dataframe df
df.head()


# In[95]:


## Analyse de la corrélation entre le sexe des clients et les catégories de produits achetés


# In[96]:


#Création du tableau de contingence "Matrice des valeurs observées"
#Variables 'sex' et 'categ' du dataframe df
X = 'sex'
Y = 'categ'

#Calcul du tableau de contigence par la méthode .pivot_table()
c = df[[X, Y]].pivot_table(index=X, columns=Y, aggfunc=len) ###, margins=True, margins_name='Total'
tx = df[X].value_counts()
ty = df[Y].value_counts()

#Création d'une copie du dataframe original
cont = c.copy()
cont


# In[97]:


#Création de la "Matrice des valeurs attendues"
#L’occurrence attendue est simplement la fréquence que l’on devrait trouver dans une cellule 
#si l’hypothèse nulle était vraie.
tx_df= pd.DataFrame(tx)
ty_df = pd.DataFrame(ty)

tx_df.columns = ["s"]
ty_df.columns = ["s"]

#Valeurs totales observées
n = len(df)

#Produit matriciel. On utilise pd.T pour pivoter une des deux séries.
indep = (tx_df.dot(ty_df.T) / n)
indep


# In[98]:


#Matrice "écart au carré normalisé de la valeur attendue VS valeur observée"
mesure = (c-indep)**2/indep
mesure


# In[99]:


#Calcul du Chi2
#Tester l’hypothèse nulle consiste à comparer les occurrences observées (celles déjà dans le tableau) 
#avec les occurrences attendues.
chi2 = mesure.sum().sum()
chi2


# In[100]:


#HeatMap 
table = (mesure/chi2)
sns.heatmap(table, annot=True, cmap="plasma", linewidths=0.1)

plt.title('HeatMap Sexe clients vs Catégorie produits')
plt.xlabel('Categ.')
plt.ylabel('Sexe')

plt.savefig("heatmap_sexe_categories.png")
plt.show()


# Le test de Chi2 est utilisé pour tester l'hypothèse nulle (H0) d'absence de relation entre deux variables catégorielles, ce test vérifie donc l'hypothèse d'indépendance de ces variables.
# 
# La valeur de Chi2 est une quantification de cet écart (entre les occurences attendues et celles observées). Plus la valeur sera élevée, plus l'écart entre l'hypothèse nulle et la situation réelle sera grand.
# 
# Plus l’occurrence observée est près de l’occurrence attendue, plus la fraction calculée pour chaque cellule est petite et moins l’écart avec H0 est grand.

# In[101]:


#Calcul du khi2 et de la p-value à partir de la matrice des valeurs observées avec scipy 
#Degré de liberté = (nombre de lignes – 1) X (nombre de colonnes – 1)
chi2, pvalue, degrees, expected = st.chi2_contingency(cont)
chi2, degrees, pvalue


# L'indice élevé du Chi2 démontre une importance significative entre les occurences théoriques et celles du tableau de contigence. De plus, la comparaison de p-value (4e-16%) avec notre seuil de significativité (traditionnellement 5%) expose une valeur inférieure au seuil. L'hypothèse nulle est rejetée en faveur de l’hypothèse alternative, il existe donc un lien entre le sexe des clients et les catégories produits.

# ##  Analyse de la corrélation entre l'âge clients et le montant total des achats

# In[102]:


#Agrégation pour sommer les ventes 'price' (produits achetés) en fonction de l'âge des clients
#Création d'une variable 'age_price'
age_price = df.groupby('age').sum().reset_index()
age_price = age_price[['age', 'price']].sort_values(by='age', ascending=False) 
age_price['price'] = age_price['price'] / 1000 #Valeurs exprimées en K€

age_price.head() #Apperçu des données âges / ventes


# In[103]:


age_price.tail()


# In[104]:


#Visualisation avec un scatterplot (âge clients vs montant total des achats)
plt.plot(age_price[age_price.price < 200].age, age_price[age_price.price < 200].price, 'o', color='green')

plt.xlabel('age')
plt.ylabel('Montant achat (K€)')
plt.title('Montant Total des achats selon l\'âge du client')

plt.savefig("scatterplot_montant_achat_age_client.png")
plt.show()


# In[105]:


#Coefficient de corrélation linéaire de Pearson
coef_age_price = st.pearsonr(age_price.age, age_price.price)[0]
coef_age_price


# Le coefficient est négatif par conséquent, on peut émettre l'hypothèse que plus les consommateurs sont agés plus le montant total de leur achat est faible. Ce coefficient est plus proche de -1 que de zéro.on est donc face à une forte correlation

# ## Analyse de la corrélation entre l'âge clients et la fréquence d'achat¶
# 

# Ici la fréquence d'achat correspond au nombre d'achats par mois

# In[106]:


#Analyse faite à partir du dataframe global df
df.head()


# In[107]:


#Agrégation des données selon l'âge client
#Le nombre d'achat mensuel est obtenu à partir du comptage des sessions clients par mois
#Hypothèse 1 id_session = 1 transation
customers_freq = df.groupby('age').count().reset_index()
customers_freq = customers_freq[['age', 'session_id']]

#Création d'une variable fréquence 'f'
customers_freq['f'] = customers_freq['session_id'] / sum(customers_freq['session_id'])
customers_freq.sort_values(by='age', ascending=False).head(10)


# In[108]:


#Visualisation avec un scatterplot (âge client vs fréquence d'achat mensuelle)
#customers_freq.plot.scatter(x = 'age', y = 'f', marker = 'o', color='purple')
plt.plot(customers_freq[customers_freq.f < .05].age, customers_freq[customers_freq.f < .05].f, 'o')

plt.xlabel('age')
plt.ylabel('Fréquence achat')
plt.title('Fréquence des achats selon l\'age du client')

plt.savefig("scatterplot_frequence_achat_age_client.png")
plt.show()


# In[109]:


#Coefficient de corrélation linéaire de Pearson
coef_customers_freq = st.pearsonr(customers_freq.age, customers_freq.f)[0]
coef_customers_freq


# Corrélation confirmée par le coefficient de Pearson, il existe bien un lien entre l'âge des clients et leurs fréquences d'achat. Il semblerait que des groupes de clients se formalisent sur cette corrélation, par exemple entre 18 et 30 ans.

# ## Analyse de la corrélation entre l'âge clients et la taille du panier moyen

# ici la taille du panier moyen sera exprimée en nombre d'articles

# In[110]:


#Analyse faite à partir du dataframe global df
df.head()


# In[111]:


#Première agrégation selon l'age client et les sessions en comptage de modalités
customers_shop = df.groupby(['age', 'session_id']).count().reset_index()

#Seconde agrégation selon l'age client en moyenne de produits achetés 
customers_shop = customers_shop.groupby('age').mean().reset_index()
customers_shop = customers_shop[['age', 'id_prod']]
customers_shop.tail()


# In[112]:


#Visualisation avec un scatterplot (âge client vs taille panier moyen)
plt.plot(customers_shop.age, customers_shop.id_prod, 'o', color='purple')

plt.xlabel('age')
plt.ylabel('Panier moyen (Nbe de produits)')
plt.title('Panier moyen en nombre de produits selon l\'age client')

plt.savefig("scatterplot_panier_moyen_age_client.png")
plt.show()


# In[113]:


#Subsets pour identifier les clusters clients 
customers_shop31 = customers_shop[customers_shop.age < 31]
customers_shop3050 = customers_shop[(customers_shop.age > 31) & (customers_shop.age < 50)]
customers_shop50 = customers_shop[customers_shop.age > 51]


# In[114]:


#Visualisation avec scatterplot selon les groupes d'individus identifiés
plt.plot(customers_shop31.age, customers_shop31.id_prod, '+', color='green')
plt.plot(customers_shop3050.age, customers_shop3050.id_prod, '+', color='blue')
plt.plot(customers_shop50.age, customers_shop50.id_prod, '+', color='purple')

plt.xlabel('age')
plt.ylabel('Panier moyen (Nbe de produits)')
plt.title('Panier moyen en nombre de produits selon l\'age client')

plt.savefig("scatterplot_panier_moyen_age_client_clusters.png")
plt.show()


# In[115]:


#Coefficient de corrélation linéaire de Pearson
coef_customers_shop = st.pearsonr(customers_shop.age, customers_shop.id_prod)
coef_customers_shop


# Le test de corrélation démontre un certain lien entre l'âge du client et le panier moyen. Par exemple, sur les individus de plus de 50 ans, le panier moyen reste faible. Il existe également un lien sur les individus de 18 à 30 ans et de 30 à 50 ans. La linéarité de la corrélation existe mais selon des corpus de clients visiblement distincts, par tranches d'âges.

# ## Analyse de la corrélation entre l'âge clients et la catégorie produits

# Afin de simplifier l'analyse, il est nécessaire de procéder par un découpage en classes (discrétisation). Donc très clairement le but est de pouvoir réduire nos individus "âges" par classes, de manière à pouvoir interpréter plus facilement les résultats.
# 
# Comment choisir le nombre de classes?
# 
# Avec par exemple la formule de Sturges-Huntsberger : k = 1 + 3.33*log(N,base=10)
# 
# ou encore Brooks-Carruthers : k = 5*log(N,base=10)

# In[116]:


#N est le nombre d'observations, ici représentées par les valeurs transactionnelles par âge et par catégorie
len(df.groupby(['age', 'categ']).count().reset_index())


# In[117]:


#Formule de Huntsberger : 1 + 3,3*log10(N)
1 + ((10/3) * mth.log10(227))


# In[118]:


#Formule de Brooks-Carruthers : 5*log10(N)
5 * mth.log10(227)


# Dans notre contexte, nous pouvons retenir un nombre de classes de 9.

# In[119]:


#Méthode .groupby() pour agréger les données selon l'âge et la catégorie
age_categ = df.groupby(['age', 'categ']).count().reset_index()
age_categ = age_categ[['age', 'categ', 'session_id']]
age_categ.head()


# In[120]:


#Méthode .cut() pour créer les 9 groupes d'âges, une segmentation des individus 'age'
age_categ['age']= pd.cut(age_categ['age'], 9)
age_categ = age_categ.groupby(['age','categ']).sum().reset_index()
age_categ.head(10)


# In[121]:


#Visualisation rapide avec une BarPlot Seaborn
fig, ax = plt.subplots(figsize=(22, 12))
sns.barplot(x="age", y="session_id",hue="categ", data=age_categ)

ax.set_xlabel('age')
ax.set_ylabel('Nombre de produits vendus')
ax.set_title('Catégories produits selon l\'âge client')

plt.savefig("barplot_categorie_produit_age_client")
plt.show()


# In[122]:


#Coefficient de corrélation eta carré
X = "categ" #qualitative
Y = "age" #quantitative

def eta_squared(x,y):
    moyenne_y = y.mean()
    classes = []
    for classe in x.unique():
        yi_classe = y[x==classe]
        classes.append({'ni': len(yi_classe),
                        'moyenne_classe': yi_classe.mean()})
    SCT = sum([(yj-moyenne_y)**2 for yj in y])
    SCE = sum([c['ni']*(c['moyenne_classe']-moyenne_y)**2 for c in classes])
    return SCE/SCT


# In[123]:


round(eta_squared(age_categ.age, age_categ.session_id), 2)


# Le rapport de corrélation est proche de 0.40, ce qui précise le précédent graphique dans lequel une certaine corrélation entre les catégories et l'âge client. Il est perceptible de voir le lien que peut avoir une catégorie en fonction d'une tranche d'âges, avec par exemple un fort succès de la catégorie 0 pour les 34 / 44 ans, ou à l'inverse une clientèle plus âgée n'adhère quasiment pas à cette catégorie, etc..

# ## Conclusion
# 
# L'analyse exploratoire faite à partir de ces 3 sources de données a permis d'avoir une première approche unidimensionnelle, à savoir la ressemblance entre individus, la variabilité des données, etc. par la suite nous avons procédé à une analyse multidimensionnelle qui a permis d'identifier les possibles corrélations entre les variables.
# 
# Il serait interessant de pousser l'analyse sur d'autres aspects business comme celui de la méthode d'acquisition du prospect, l'origine de la transaction client, avec par exemple une question : canal internet (si oui dans quel localité se trouve le client?) ou magasin physique (si oui lequel?).
